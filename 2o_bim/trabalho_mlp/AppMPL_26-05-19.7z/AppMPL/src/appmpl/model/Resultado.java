/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appmpl.model;

/**
 *
 * @author Alexandre LM
 */
public class Resultado
{
    public double[][] i_entrada_oculta,i_oculta_saida;
    public double[][] net_entrada_oculta,net_oculta_saida;
    
    
}
