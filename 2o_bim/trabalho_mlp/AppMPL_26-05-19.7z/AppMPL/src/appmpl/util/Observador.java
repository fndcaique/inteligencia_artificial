package appmpl.util;

public interface Observador
{
    // MÉTODO(S) ABSTRATO(S):
    public abstract void update(double x, double y);
    
    public abstract void clear();
}