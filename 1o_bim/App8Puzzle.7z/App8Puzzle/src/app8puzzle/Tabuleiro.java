/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app8puzzle;

import java.util.ArrayList;
import java.util.Stack;
import javafx.util.Pair;

/**
 *
 * @author fndcaique
 */
public class Tabuleiro {

    private int[][] matrix;
    private int N, N2, px, py, IDX;
    private Stack<Pair<Integer, Integer>> caminho, manhattan;
    private ArrayList<int[][]> visits;

    private final int[] dx = {-1, 1, 0, 0}, dy = {0, 0, -1, 1};
    private final int TF = 3, LEFT = 0, RIGHT = 1, UP = 2, DOWN = 3, DIRECTIONS = 4;

    public Tabuleiro(int n) {
        this.N = n;
        this.N2 = N * N;
        matrix = new int[n][n];
        visits = new ArrayList<>();
        manhattan = new Stack<>();
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                manhattan.add(new Pair<>(i, j));
            }
        }
    }

    /**
     * utilize-a para preencher a matrix problema, informando as coordenadas de
     * onde estão os valores atuais
     */
    public void setValue(int y, int x, int v) {
        matrix[y][x] = v;
    }

    /**
     * informe a coordenada do curinga recomenda-se que o curinga seja um valor
     * não necessário para a ordem da matrix resultado -1 ou 9 por exemplo
     */
    public void setCoordCuringa(int y, int x) {
        px = x;
        py = y;
    }

    private boolean inMatrix(int y, int x) {
        return y >= 0 && y < N && x >= 0 && x < N;
    }

    private boolean isOrdered(int m[][]) {
        boolean f = true;
        int k = 1;
        for (int i = 0; f && i < N; i++) {
            for (int j = 0; f && j < N; j++) {
                if (m[i][j] == k) {
                    ++k;
                } else {
                    f = false;
                }
            }
        }
        return k == N2;
    }

    private int qtdeInOrder() {
        int k = 1, qtde = 0;
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j, ++k) {
                if (matrix[i][j] == k) {
                    ++qtde;
                }
            }

        }
        return qtde;
    }

    private int distManhattan(int y, int x) {
        int v = matrix[y][x];
        Pair<Integer, Integer> coord = manhattan.get(v);
        return Math.abs(y - coord.getKey()) + Math.abs(x - coord.getValue());
    }

    private void swap(int[][] m, int y1, int x1, int y2, int x2) {
        // m[y1][x1] = a, m[y2][x2] = b,   a = 0100, b = 1011
        m[y1][x1] ^= m[y2][x2]; // a ^= b, a = 1111, b = 1011
        m[y2][x2] ^= m[y1][x1]; // b ^= a, a = 1111, b = 0100
        m[y1][x1] ^= m[y2][x2]; // a ^= b, a = 1011, b = 0100 
    }

    private int[][] copy(int[][] m) {
        int[][] a = new int[m.length][m[0].length];
        for (int i = 0; i < m.length; ++i) {
            for (int j = 0; j < m[0].length; ++j) {
                a[i][j] = m[i][j];
            }
        }
        return a;
    }

    private boolean equals(int a[][], int b[][]) {
        for (int i = 0; i < a.length; ++i) {
            for (int j = 0; j < b[0].length; ++j) {
                if (a[i][j] != b[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    private int findVisits(int e[][]) {
        for (int i = visits.size() - 1; i >= 0; --i) {
            if (equals(e, visits.get(i))) {
                return i;
            }
        }
        return -1;
    }

    public void exibeMatrix() {
        System.out.println("--------Matrix---------");
        for (int[] is : matrix) {
            for (int i : is) {
                System.out.print(i + ", ");
            }
            System.out.println("");
        }
        System.out.println("######################");
    }

    public ArrayList<int[][]> getVisits() {
        return visits;
    }

    public void exibeMatrix(int[][] ma) {
        System.out.println("--------Matrix---------");
        for (int[] is : ma) {
            for (int i : is) {
                System.out.print(i + ", ");
            }
            System.out.println("");
        }
        System.out.println("######################");
    }

    public void exibeVisits() {

        for (int[][] visit : visits) {
            System.out.println("Visitada:");
            exibeMatrix(visit);
        }
    }

    public Stack<Pair<Integer, Integer>> getSolucaoDfs() {

        caminho = new Stack<>();
        if (solve()) {
            System.out.println("ACHOU");
        } else {
            System.out.println("NÃO ACHOU");
        }
        System.out.println("*********FIM**********");
        return caminho;
    }

    private boolean solve(int y, int x) {
        //exibeVisits();
        int id = visits.size();
        visits.add(copy(matrix));
        //System.out.println("ID = " + id);
        //exibeMatrix();
        if (isOrdered(visits.get(id))) {
            caminho.push(new Pair<>(y, x));
            System.out.println("CHEGOU");
            return true;
        }
        if (qtdeInOrder() >= 4) {
            exibeMatrix(matrix);
        }
        int solve = 0, nx, ny;
        for (int i = 0; i < DIRECTIONS; ++i) {
            ny = dy[i] + y;
            nx = dx[i] + x;
            if (inMatrix(ny, nx)) {
                swap(matrix, y, x, ny, nx);
                //exibeMatrix(matrix);
                int pos = findVisits(matrix);
                if (pos == -1) { // não visitou
                    if (solve(ny, nx)) { // achou solucao
                        caminho.push(new Pair<>(y, x));
                        System.out.println("CHEGOU");
                        return true;
                    }
                    //visits.remove(id+1);
                } else {
                    //System.out.println("estado acima ja tentado, pos = " + pos);

                }
                //System.out.println("ID = " + id);
                swap(matrix, y, x, ny, nx);
                //exibeMatrix(matrix);

            }
        }
        return false;
    }

    private boolean solve() {
        int x = px, y = py, d;
        int[][] mat = copy(matrix);
        Stack<Integer> p1 = new Stack<>();
        Stack<int[][]> p2 = new Stack<>();
        p1.push(0);
        p1.push(x);
        p1.push(y);
        p2.push(mat);

        boolean f = false;
        while (!p1.isEmpty()) {
            y = p1.pop();
            x = p1.pop();
            d = p1.pop();

            mat = p2.pop();
            visits.add(copy(mat));

            //exibeMatrix(mat);
            //System.out.println("curinga("+y+", "+x+")");
            if (!isOrdered(mat) && !f) {
                for (int i = 0; i < DIRECTIONS; ++i) {
                    if (inMatrix(y + dy[i], x + dx[i])) {
                        swap(mat, y + dy[i], x + dx[i], y, x);
                        if (findVisits(mat) == -1) { // não visitado
                            p1.push(i);
                            p1.push(x + dx[i]);
                            p1.push(y + dy[i]);

                            p2.push(copy(mat));
                        }
                        swap(mat, y + dy[i], x + dx[i], y, x);
                    }
                }
            } else {
                exibeMatrix(mat);
                //System.out.println("ACHOU");
                f = true;
            }
        }
        return f;
    }

}
